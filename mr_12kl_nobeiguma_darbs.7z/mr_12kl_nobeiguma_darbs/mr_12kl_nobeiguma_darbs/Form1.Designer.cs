﻿namespace mr_12kl_nobeiguma_darbs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.login_poga = new System.Windows.Forms.Button();
            this.reg_poga = new System.Windows.Forms.Button();
            this.lietotaja_vards = new System.Windows.Forms.TextBox();
            this.lietotaja_parole = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.Location = new System.Drawing.Point(157, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Auto detaļu tāme ";
            // 
            // login_poga
            // 
            this.login_poga.Location = new System.Drawing.Point(299, 277);
            this.login_poga.Name = "login_poga";
            this.login_poga.Size = new System.Drawing.Size(131, 52);
            this.login_poga.TabIndex = 1;
            this.login_poga.Text = "Ielogoties!";
            this.login_poga.UseVisualStyleBackColor = true;
            this.login_poga.Click += new System.EventHandler(this.login_poga_Click);
            // 
            // reg_poga
            // 
            this.reg_poga.Location = new System.Drawing.Point(73, 277);
            this.reg_poga.Name = "reg_poga";
            this.reg_poga.Size = new System.Drawing.Size(131, 52);
            this.reg_poga.TabIndex = 2;
            this.reg_poga.Text = "Reģistrēties!";
            this.reg_poga.UseVisualStyleBackColor = true;
            this.reg_poga.Click += new System.EventHandler(this.reg_poga_Click);
            // 
            // lietotaja_vards
            // 
            this.lietotaja_vards.Location = new System.Drawing.Point(172, 135);
            this.lietotaja_vards.Name = "lietotaja_vards";
            this.lietotaja_vards.Size = new System.Drawing.Size(167, 20);
            this.lietotaja_vards.TabIndex = 3;
            // 
            // lietotaja_parole
            // 
            this.lietotaja_parole.Location = new System.Drawing.Point(172, 201);
            this.lietotaja_parole.Name = "lietotaja_parole";
            this.lietotaja_parole.Size = new System.Drawing.Size(167, 20);
            this.lietotaja_parole.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.Location = new System.Drawing.Point(141, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Ievadiet lietotāja vārdu!";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label3.Location = new System.Drawing.Point(141, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Ievadiet lietotāja paroli!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 385);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lietotaja_parole);
            this.Controls.Add(this.lietotaja_vards);
            this.Controls.Add(this.reg_poga);
            this.Controls.Add(this.login_poga);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button login_poga;
        private System.Windows.Forms.Button reg_poga;
        private System.Windows.Forms.TextBox lietotaja_vards;
        private System.Windows.Forms.TextBox lietotaja_parole;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

